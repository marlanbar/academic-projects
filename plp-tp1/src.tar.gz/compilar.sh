ghc -o testTP1 mapReduce.hs mapReduceSpec.hs
