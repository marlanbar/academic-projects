
Para testear el TP, recomendamos usar HSpec (un framework de testing de
Haskell http://hspec.github.io/). Para instalar HSpec:

- Instalar Cabal (el administrador de paquetes de Haskell)
  usando el administrador de paquetes del sistema operativo.
  El paquete se llama "cabal-install" en Ubuntu o Arch.
  Más información sobre Cabal:

    http://www.haskell.org/haskellwiki/Cabal-Install

- Usando Cabal, instalar el módulo HUnit y HSpec:
    cabal update
    cabal install HUnit
    cabal install HSpec

