class Receptor():
	def getTelefono(self):
		raise NotImplemented("'getTelefono' no fue implementado")
	def getNombre(self):
		raise NotImplemented("'getNombre' no fue implementado")