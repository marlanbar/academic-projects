class Notificador():
	def serNotificado(self):
		raise NotImplemented("'serNotificado' no fue implementado")