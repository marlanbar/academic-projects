class Autoridad():
	def getNombre(self):
		raise NotImplemented("'getNombre' no fue implementado")
	def puedeVisualizarInfoDeCurso(self):
		raise NotImplemented("'puedeVisualizarInfoDeCurso' no fue implementado")