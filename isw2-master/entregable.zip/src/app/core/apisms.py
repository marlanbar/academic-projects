class APISMS():
	def enviar(self, telefono, texto):
		raise NotImplemented("'enviar' no fue implementado")