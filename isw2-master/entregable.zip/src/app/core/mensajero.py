class Mensajero():
	def enviarMensajeA(self, unMensaje, unReceptor):
		raise NotImplemented("'enviarMensajeA' no fue implementado")